package com.linda.pulserateapp;

public interface CheckSwitchSMSState {

    public void onChanged(boolean state);

}
