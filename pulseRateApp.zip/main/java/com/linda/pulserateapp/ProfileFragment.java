package com.linda.pulserateapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ProfileFragment extends Fragment {

    // Variable initialisation
    private Button updateDataBtn;
    private Button addContactBtn;
    private ListView emergencyContactListListView;
    private ArrayList<String> contacts;
    private ArrayAdapter listAdapter;

    // This value is to check if the first string of "contacts" array is not empty (so it is to avoid to add an "empty" string)
    private int addContactHelper = 0;
    private SharedPreferences contactsPreferences;
    private SharedPreferences addContactHelperPreferences;

    private TextView userIdTextView;
    private EditText firstNameEditText;
    private EditText lastNameEditText;
    private EditText ageEditText;

    private String firstName = "";
    private String lastName = "";
    private String age = "";
    private SharedPreferences userDataPreferences;

    UpdateDataButtonListener updateDataButtonListener;
    AddContactButtonListener addContactButtonListener;

    // Random user id
    final String USER_ID = "0987654321";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Set the layout paired with this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Set all the buttons, TextViews, and EditTexts and ListViews
        updateDataBtn = (Button) view.findViewById(R.id.update_data_btn);
        addContactBtn = (Button) view.findViewById(R.id.add_contact_btn);
        emergencyContactListListView = (ListView) view.findViewById(R.id.emergency_contact_list_listview);

        userIdTextView = (TextView) view.findViewById(R.id.user_id_txtview);
        firstNameEditText = (EditText) view.findViewById(R.id.user_firstname_edit_text);
        lastNameEditText = (EditText) view.findViewById(R.id.user_lastname_edit_text);
        ageEditText = (EditText) view.findViewById(R.id.user_age_edit_text);

        userIdTextView.setText(USER_ID);
        contacts = new ArrayList<String>();
        listAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, contacts);
        emergencyContactListListView.setAdapter(listAdapter);

        // Get the last emergency contact list, user data from all the SharedPreferences
        contactsPreferences = this.getActivity().getSharedPreferences("CONTACTS", Context.MODE_PRIVATE);
        addContactHelperPreferences = this.getActivity().getSharedPreferences("ADD_CONTACT_HELPER", Context.MODE_PRIVATE);
        userDataPreferences = this.getActivity().getSharedPreferences("USER_DATA", Context.MODE_PRIVATE);

        loadUserData();
        loadAddContactHelper();
        loadEmergencyContactList();

        // On the click of the "Add contact" button...
        addContactBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Create a AlertDialog and in this AlertDialog...
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());

                // Set the title
                alertDialog.setTitle("New Emergency Contact");
                final EditText editText = new EditText(getActivity().getApplicationContext());
                alertDialog.setView(editText);

                // Add a "Positive" button named "Add" into the AlertDialog and if this button is clicked
                // Add the new contact in the "contacts" array, save the updated "contacts" array
                // Then create and send an Intent to the MainActivity with the user data and the new "contacts" array
                // Moreover reset the number of sent messages
                alertDialog.setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.i("Add Number", "|"+editText.getText().toString()+"|");
                        addContactHelper++;
                        addContact(editText.getText().toString());
                        listAdapter.notifyDataSetChanged();
                        saveEmergencyContactList();
                        saveAddContactHelper();

                        String getFirstName = firstNameEditText.getText().toString();
                        String getLastName = lastNameEditText.getText().toString();
                        String getAge = ageEditText.getText().toString();

                        if(getFirstName.equals("") || getLastName.equals("") || getAge.equals("")){
                            Toast.makeText(getContext(), "Please fill your profile", Toast.LENGTH_SHORT).show();
                        } else {
                            Intent intent = new Intent(getActivity(), MainActivity.class);
                            intent.putExtra("firstname", firstName);
                            intent.putExtra("lastname", lastName);
                            intent.putExtra("age", age);
                            intent.putExtra("user_id", USER_ID);
                            intent.putStringArrayListExtra("contacts", contacts);
                            addContactButtonListener.onClickAddContactButton(intent);
                            Log.i("Frag: Intent sent", "Contact sent !");

                            MainActivity mainActivity = (MainActivity) getActivity();
                            mainActivity.count = 0;
                            Log.i("Count value", String.valueOf(mainActivity.count));
                        }

                    }
                });

                // Display the AlertDialog
                final AlertDialog dialog = alertDialog.show();
                dialog.show();

            }
        });

        // On the click of the "Update data" button...
        updateDataBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Get the new user data written by the user
                String getFirstName = firstNameEditText.getText().toString();
                String getLastName = lastNameEditText.getText().toString();
                String getAge = ageEditText.getText().toString();

                // If one of those user data is empty the display a Toast to ask the user to fill all the blanks
                if (getFirstName.equals("") || getLastName.equals("") || getAge.equals("")) {
                    Toast.makeText(getContext(), "Please fill all the blanks", Toast.LENGTH_SHORT).show();
                }
                // Otherwise save the new user data then create and send an Intent to the MainActivity with the user data and the new "contacts" array
                // However, check if the "contacts" array is not empty and if the first contact is different from an empty string
                else {
                    firstName = getFirstName;
                    lastName = getLastName;
                    age = getAge;
                    saveUserData();

                    Intent intent = new Intent(getActivity(), MainActivity.class);
                    intent.putExtra("firstname", firstName);
                    intent.putExtra("lastname", lastName);
                    intent.putExtra("age", age);
                    intent.putExtra("user_id", USER_ID);
                    Log.i("Contact", "|"+contacts.get(0).toString()+"|");

                    if(!(contacts.isEmpty()) && !(contacts.get(0).toString().equals(""))){
                        intent.putStringArrayListExtra("contacts", contacts);
                        updateDataButtonListener.onClickUpdateDataButton(intent);
                        Toast.makeText(getContext(), "Data updated !", Toast.LENGTH_SHORT).show();
                        Log.i("Frag : Intent sent", "User data sent !");

                        MainActivity mainActivity = (MainActivity) getActivity();
                        mainActivity.count = 0;
                        Log.i("Count value", String.valueOf(mainActivity.count));
                    } else {
                        Toast.makeText(getContext(), "Please provide at least one contact", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });

        return view;
    }

    // Add new contact in the "contacts" array
    public void addContact(String number){
        if(!(number.equals(""))) {
            contacts.add(number);
        }
        else {
            Toast.makeText(getContext(), "Please enter a valid number", Toast.LENGTH_SHORT).show();
        }
        // If the first string of the "contacts" array is empty then remove it
        // (Done because the number for the first time was always empty
        if(addContactHelper == 1){
            contacts.remove(0);
        }
        for(int i=0; i<contacts.size(); i++){
            Log.i("Contact", "|"+contacts.get(i).toString()+"|");
        }

    }

    // Save the whole Emergency Contact list in SharedPreferences
    public void saveEmergencyContactList(){
        StringBuilder stringBuilder = new StringBuilder();
        for(String number : contacts){
            stringBuilder.append(number.replace("\n", ""));
            Log.i("StringBuilder", "|"+number+"|");
            stringBuilder.append(",");
        }
        SharedPreferences.Editor editor = contactsPreferences.edit();
        editor.putString("contacts", stringBuilder.toString());
        editor. commit();
    }

    // Load the the whole Emergency Contact list in SharedPreferences
    public void loadEmergencyContactList(){
        String contactsString = contactsPreferences.getString("contacts", "");
        String[] itemContacts = contactsString.split(",");
        for (int i=0; i<itemContacts.length; i++){
            contacts.add(itemContacts[i]);
        }
    }

    // Save the "addContactHelper" variable in SharedPreferences
    public void saveAddContactHelper(){
        SharedPreferences.Editor editor = addContactHelperPreferences.edit();
        editor.putInt("addContactHelper", addContactHelper);
        editor.commit();
    }

    // Load the "addContactHelper" variable
    public void loadAddContactHelper(){
        addContactHelper = addContactHelperPreferences.getInt( "addContactHelper", addContactHelper);
    }

    // Save the user data in SharedPreferences
    public void saveUserData(){
        SharedPreferences.Editor editor = userDataPreferences.edit();
        editor.putString("firstname", firstName);
        editor.putString("lastname", lastName);
        editor.putString("age", age);
        editor.commit();
    }

    // Load the user date from the SharedPreferences
    public void loadUserData(){
        firstName = userDataPreferences.getString("firstname", firstName);
        lastName = userDataPreferences.getString("lastname", lastName);
        age = userDataPreferences.getString("age", age);

        firstNameEditText.setText(firstName);
        lastNameEditText.setText(lastName);
        ageEditText.setText(age);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            updateDataButtonListener = (UpdateDataButtonListener) context;
            addContactButtonListener = (AddContactButtonListener) context;
        } catch (ClassCastException e){
            e.printStackTrace();
        }
    }

}
