package com.linda.pulserateapp;

import android.content.Intent;

public interface UpdateDataButtonListener {

    public void onClickUpdateDataButton(Intent intent);

}
