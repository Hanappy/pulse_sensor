package com.linda.pulserateapp;

import android.content.Intent;

public interface AddContactButtonListener {

    public void onClickAddContactButton(Intent intent);

}
