package com.linda.pulserateapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;

import static android.content.Context.MODE_PRIVATE;

public class SettingsFragment extends Fragment {

    // Variable initialisation
    private Switch switchSendSMS;
    private boolean stateSwitchSendSMS;
    private SharedPreferences preferences;
    private static final String PREFERENCES_NAME = "SwitchState";

    // Emulator Number (it was just to try if SMS was well sent)
    private String contact = "15555215554";
    private String message = "Switch True";
    CheckSwitchSMSState mListener;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Set the layout that will be printed
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        // Get the last SMS switch state from all the SharedPreferences
        preferences = this.getActivity().getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE);
        // Set the SMS switch
        switchSendSMS = (Switch) view.findViewById(R.id.sendSMS_switch);
        // Put the SMS switch in the state gotten back from preferences
        switchSendSMS.setChecked(preferences.getBoolean("stateSwitchSendSMS", stateSwitchSendSMS));

        return view;
    }

    // When the Fragment is running...
    @Override
    public void onResume() {
        super.onResume();

        switchSendSMS.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                stateSwitchSendSMS = isChecked;
                saveStateSwitchSendSMS();
                Log.i("Frag: Switch SMS State", String.valueOf(stateSwitchSendSMS));

                // If the SMS Switch is turned on then check the "SMS" permission is granted
                if(stateSwitchSendSMS == true){
                    ((MainActivity)getActivity()).checkSMSPermissions();
                }
                // If the SMS Switch is turned off then reset the number of send messages
                if(stateSwitchSendSMS == false){
                    ((MainActivity)getActivity()).count = 0;
                }
                // Always check the SMS switch state to send the changed of state to the MainActivity
                if(mListener != null){
                    Log.i("Frag: Listener sent", String.valueOf(stateSwitchSendSMS));
                    mListener.onChanged(stateSwitchSendSMS);
                }

            }
        });
    }

    // Save the SMS switch state in Shared Preferences
    private void saveStateSwitchSendSMS(){
        SharedPreferences sharePref = this.getActivity().getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharePref.edit();
        editor.putBoolean("stateSwitchSendSMS", stateSwitchSendSMS);
        editor.commit();
        //Toast.makeText(getContext(), "State saved", Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            mListener = (CheckSwitchSMSState) context;
        } catch (ClassCastException e){
            e.printStackTrace();
        }
    }
}
