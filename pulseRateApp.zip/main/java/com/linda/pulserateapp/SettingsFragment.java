package com.linda.pulserateapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;

import static android.content.Context.MODE_PRIVATE;

public class SettingsFragment extends Fragment {

    private Switch switchSendSMS;
    private boolean stateSwitchSendSMS;
    private SharedPreferences preferences;
    private static final String PREFERENCES_NAME = "SwitchState";

    private String contact = "15555215554";
    private String message = "Switch True";
    CheckSwitchSMSState mListener;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        preferences = this.getActivity().getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE);
        switchSendSMS = (Switch) view.findViewById(R.id.sendSMS_switch);

        switchSendSMS.setChecked(preferences.getBoolean("stateSwitchSendSMS", stateSwitchSendSMS));

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        switchSendSMS.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                stateSwitchSendSMS = isChecked;
                saveStateSwitchSendSMS();
                Log.i("Frag: Switch SMS State", String.valueOf(stateSwitchSendSMS));

                if(stateSwitchSendSMS == true){
                    ((MainActivity)getActivity()).checkSMSPermissions();
                }
                if(stateSwitchSendSMS == false){
                    ((MainActivity)getActivity()).count = 0;
                }

                if(mListener != null){
                    Log.i("Frag: Listener sent", String.valueOf(stateSwitchSendSMS));
                    mListener.onChanged(stateSwitchSendSMS);
                }

            }
        });
    }

    private void saveStateSwitchSendSMS(){
        SharedPreferences sharePref = this.getActivity().getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharePref.edit();
        editor.putBoolean("stateSwitchSendSMS", stateSwitchSendSMS);
        editor.commit();
        //Toast.makeText(getContext(), "State saved", Toast.LENGTH_SHORT).show();
    }

    /*protected void sendSMSMessage() {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(contact, null, message, null, null);
        Toast.makeText(getContext(), "SMS sent.",
                Toast.LENGTH_LONG).show();
    }*/

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            mListener = (CheckSwitchSMSState) context;
        } catch (ClassCastException e){
            e.printStackTrace();
        }
    }
}
