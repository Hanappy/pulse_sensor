package com.linda.pulserateapp;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements CheckSwitchSMSState,AddContactButtonListener,UpdateDataButtonListener {

    // Variables initialisation
    private ActionBar toolbar;
    private BottomNavigationView bottomNavigationView;
    private boolean stateSwitchSendSMS;

    RequestQueue requestQueue;
    // ID of the ThingSpeak Channel used
    private String CHANNEL_ID = "620080";
    // Read API Key of the ThingSpeak Channel used
    private String READ_API_KEY = "5JV8F8O1J1FSMW7G";

    // Url Addresses to get the last value of each channel (Field 1 -> Pulse Rate and Field 2 -> Accelerometer)
    private String pulseUrlAddress = "https://api.thingspeak.com/channels/"+ CHANNEL_ID +"/fields/1.json?api_key="+ READ_API_KEY +"&results=1";
    private String accelerometerUrlAddress = "https://api.thingspeak.com/channels/"+ CHANNEL_ID +"/fields/2.json?api_key="+ READ_API_KEY +"&results=1";

    private int lastMeasure;
    private BroadcastReceiver minuteUpdateReceiver;
    // Maximum number of SMS
    private int maxNumberSMS = 3;
    // Number of send messages
    public int count = 0;

    private String firstName = "";
    private String lastName = "";
    private String age = "";
    private String user_id = "";
    private ArrayList<String> contacts;

    private SharedPreferences switchStatePreferences;
    private SharedPreferences profileFragmentDataPreferences;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1;
    private static final int MY_PERMISSIONS_REQUEST_READ_PHONE_STATE = 1;

    private Thread thread;
    private int pulseRateMaxValue = 100;
    private int pulseRateMinValue = 60;
    private int lastUserActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the layout that will be printed
        setContentView(R.layout.activity_main);

        // Check the "Phone State" permission
        checkPhoneStatePermissions();

        // Create a toolbar on the top of the screen
        toolbar = getSupportActionBar();

        // Get the last saved data from all the SharedPreferences
        switchStatePreferences = getSharedPreferences("SMS_SWITCH_STATE", MODE_PRIVATE);
        profileFragmentDataPreferences = getSharedPreferences("PROFILE_FRAGMENT_DATA", MODE_PRIVATE);
        stateSwitchSendSMS = switchStatePreferences.getBoolean("stateSwitchSendSMS", stateSwitchSendSMS);
        contacts = new ArrayList<String>();
        loadProfileFragmentData();

        // Disable the big selection effect on the Bottom Navigation Bar
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavigationView);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


        // Set the title from the upper toolbar
        toolbar.setTitle("Today");
        // Load the TodayFragment
        loadFragment(new TodayFragment());

        // Allow to make JSON Request (Essential !!!)
        requestQueue = Volley.newRequestQueue(this);

        // Thread to update the last measurement and the last user state during this measurement every five second
        thread = new Thread(){
            @Override
            public void run() {
                while (!isInterrupted()){
                    try{
                        if(!MainActivity.this.isDestroyed()) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    getLastMeasure();
                                    getLastUserActivity();
                                }
                            });
                            Thread.sleep(5000);
                        }
                    } catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
            }
        };
        thread.start();

        Log.i("Begin: SMS Switch State", String.valueOf(stateSwitchSendSMS));
        Log.i("Begin: count value", String.valueOf(count));
        for (int i = 0; i < contacts.size(); i++) {
            Log.i("Contacts","|" +contacts.get(i).toString() +"|");
        }

    }

    // If an item from the Bottom Navigation Bar is selected then open the corresponding Fragment
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            Fragment fragment;

            switch (item.getItemId()){
                case R.id.ic_today :
                    item.setChecked(true);
                    toolbar.setTitle("Today");
                    fragment = new TodayFragment();
                    loadFragment(fragment);
                    break;

                case R.id.ic_statistics :
                    item.setChecked(true);
                    toolbar.setTitle("Statistics");
                    fragment = new StatisticsFragment();
                    loadFragment(fragment);
                    break;

                case R.id.ic_profile :
                    item.setChecked(true);
                    toolbar.setTitle("Profile");
                    fragment = new ProfileFragment();
                    loadFragment(fragment);
                    break;

                case R.id.ic_settings :
                    item.setChecked(true);
                    toolbar.setTitle("Settings");
                    fragment = new SettingsFragment();
                    loadFragment(fragment);
                    break;
            }

            return false;
        }
    };

    // Load the provided Fragment
    // Which means to open the fragment depending on which item is selected in bottom navigation bar
    private void loadFragment(Fragment fragment){
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    // If the MainActivity is running...
    // Update the data print on the screen each minute
    @Override
    protected void onResume() {
        super.onResume();
        startMinuteUpdater();
    }

    // If the MainActivity is on the background... (is not visible anymore)
    // Stop updating data
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(minuteUpdateReceiver);
    }

    // Send SMS made of the user's firstname, lastname, age and the last measure done
    protected void sendSMSMessage() {
        if(firstName.equals("") || lastName.equals("") || age.equals("") || user_id.equals("") || contacts.isEmpty()) {
            Toast.makeText(this, "Please fill all your profile and provide at least one contact",
                    Toast.LENGTH_LONG).show();
        } else {
            String message = "WATCH OUT !!!\n" + "ID: " + user_id + "\n" + firstName + " " + lastName + " "
                    + "(" + age + " years old)" + "\n" + "Last measure : " + lastMeasure;
            SmsManager smsManager = SmsManager.getDefault();
            for (int i = 0; i < contacts.size(); i++) {
                smsManager.sendTextMessage(contacts.get(i).toString(), null, message, null, null);
            }
            Toast.makeText(this, "SMS sent.",
                    Toast.LENGTH_LONG).show();
            count++;
            Log.i("SMS sent Number", String.valueOf(count));
        }
    }

    // Get the last pulse measurement from ThingSpeak
    public void getLastMeasure(){
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, pulseUrlAddress, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i("Info", "Main Act: Last measure received !");

                        try {
                            JSONArray feeds = response.getJSONArray("feeds");
                            JSONObject jo = feeds.getJSONObject(feeds.length()-1);

                            String field1_data = jo.getString("field1");
                            lastMeasure = Integer.parseInt(field1_data);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.i("Info", "Fail to receive data !");
                    }
                });
        requestQueue.add(jsonObjectRequest);
    }

    // Get the user activity from ThingSpeak
    public void getLastUserActivity(){
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, accelerometerUrlAddress, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i("Info", "Main Act: User activity received !");

                        try {
                            JSONArray feeds = response.getJSONArray("feeds");
                            JSONObject jo = feeds.getJSONObject(feeds.length()-1);

                            String field2_data = jo.getString("field2");
                            if(field2_data != "null") {
                                lastUserActivity = Integer.parseInt(field2_data);
                            } else {
                                lastUserActivity = 0;
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.i("Info", "Fail to receive data !");
                    }
                });
        requestQueue.add(jsonObjectRequest);
    }

    // If the SMS switch state from the Settings Fragment changes
    // Check SMS permissions to forbid SMS sending or not
    @Override
    public void onChanged(boolean state) {
        stateSwitchSendSMS = state;
        if(stateSwitchSendSMS == true){
            checkSMSPermissions();
            count = 0;
        }
        saveStateSwitchSendSMS();
        Log.i("Act: Listener received", String.valueOf(stateSwitchSendSMS));
    }

    // Send SMS every minute under specific conditions
    private void startMinuteUpdater(){
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_TIME_TICK);
        minuteUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (count < maxNumberSMS) {
                    // If the user turns on the SMS switch and if the last measurement is over than the pulseRateMaxValue (=100) and if the user is not moving
                    if ((stateSwitchSendSMS == true) && (lastMeasure > pulseRateMaxValue) && (lastUserActivity == 0) ) {
                        sendSMSMessage();
                    }
                    // If the user turns on the SMS switch and if the last measurement is smaller than the pulseRateMinValue (=60) and if the user is not moving
                    else if ((stateSwitchSendSMS == true) && (lastMeasure < pulseRateMinValue) && (lastUserActivity == 0) ) {
                        sendSMSMessage();
                    }
                    // If the user turns on the SMS switch and if the last measurement is smaller than the pulseRateMaxValue (=60) and if the user is moving
                    else if ((stateSwitchSendSMS == true) && (lastMeasure < pulseRateMinValue) && (lastUserActivity == 1) ) {
                        sendSMSMessage();
                    }
                }
                else{
                    Log.i("Count Max Value", String.valueOf(count));
                }
            }
        };
        registerReceiver(minuteUpdateReceiver, intentFilter);
    }

    // Get data from the intent provided by the Profile Fragment
    // In order to prepare the SMS which will be sent
    public void receiveProfileFragmentData(Intent intent){
        Intent intentProfile = intent;
        firstName = intentProfile.getStringExtra("firstname");
        lastName = intentProfile.getStringExtra("lastname");
        age = intentProfile.getStringExtra("age");
        user_id = intentProfile.getStringExtra("user_id");
        contacts = intentProfile.getStringArrayListExtra("contacts");
        Log.i("Act : Intent received", "Yeah !");
    }

    // When a click happens on the "Add contact" button from the Profile Fragment ...
    @Override
    public void onClickAddContactButton(Intent intent) {
        receiveProfileFragmentData(intent);
        saveProfileFragmentData();
    }

    // When a click happens on the "Update data" button from the Profile Fragment ...
    @Override
    public void onClickUpdateDataButton(Intent intent) {
        receiveProfileFragmentData(intent);
        saveProfileFragmentData();
    }

    // Save the Profile Fragment data in the SharedPreferences
    public void saveProfileFragmentData(){
        SharedPreferences.Editor editor = profileFragmentDataPreferences.edit();
        editor.putString("firstname", firstName);
        editor.putString("lastname", lastName);
        editor.putString("age", age);
        editor.putString("user_id", user_id);
        StringBuilder stringBuilder = new StringBuilder();
        for(String number : contacts){
            stringBuilder.append(number);
            stringBuilder.append(",");
        }
        editor.putString("contacts", stringBuilder.toString());
        editor.commit();
    }

    // Load the Profile Fragment data from the SharedPreferences
    public void loadProfileFragmentData(){
        firstName = profileFragmentDataPreferences.getString("firstname", firstName);
        lastName = profileFragmentDataPreferences.getString("lastname", lastName);
        age = profileFragmentDataPreferences.getString("age", age);
        user_id = profileFragmentDataPreferences.getString("user_id", user_id);
        String contactsString = profileFragmentDataPreferences.getString("contacts", "");
        String[] itemContacts = contactsString.split(",");
        for (int i=0; i<itemContacts.length; i++){
            contacts.add(itemContacts[i]);
        }
    }

    // Check if the "SMS" permission is granted
    //(Used to be able to send SMS )
    public void checkSMSPermissions(){
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED)
        {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        }
    }

    // Check if the "Phone State" permission is granted
    //(Used to be able to read SMS on the emulator)
    public void checkPhoneStatePermissions(){
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED)
        {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.READ_PHONE_STATE)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_PHONE_STATE},
                        MY_PERMISSIONS_REQUEST_READ_PHONE_STATE);
            }
        }
    }

    // Save the SMS switch state
    private void saveStateSwitchSendSMS(){
        SharedPreferences.Editor editor = switchStatePreferences.edit();
        editor.putBoolean("stateSwitchSendSMS", stateSwitchSendSMS);
        editor.commit();
        //Toast.makeText(getContext(), "State saved", Toast.LENGTH_SHORT).show();
    }

    // If the MainActivity is not visible for the user then stop it
    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }

}
