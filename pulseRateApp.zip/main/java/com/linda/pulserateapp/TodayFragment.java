package com.linda.pulserateapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TodayFragment extends Fragment {

    // Variables initialisation
    RequestQueue requestQueue;
    private TextView txtViewLastMeasure;
    private TextView txtViewLastUserActivity;
    private TextView txtViewLastMeasureDate;
    private TextView txtViewLastMeasureHour;

    // ID of the ThingSpeak Channel used
    private String CHANNEL_ID = "620080";
    // Read API Key of the ThingSpeak Channel used
    private String READ_API_KEY = "5JV8F8O1J1FSMW7G";

    // Url Addresses to get the last value of each channel (Field 1 -> Pulse Rate and Field 2 -> Accelerometer)
    String pulseUrlAddress = "https://api.thingspeak.com/channels/"+ CHANNEL_ID +"/fields/1.json?api_key="+ READ_API_KEY +"&results=1";
    String accelerometerUrlAddress = "https://api.thingspeak.com/channels/"+ CHANNEL_ID +"/fields/2.json?api_key="+ READ_API_KEY +"&results=1";

    private Thread thread;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Set the layout that will be printed
        View view = inflater.inflate(R.layout.fragment_today_improved, container, false);

        // Set all the textViews
        txtViewLastMeasure = (TextView) view.findViewById(R.id.last_measure_txt_view_imp);
        txtViewLastUserActivity = (TextView) view.findViewById(R.id.last_user_activity_txt_view_imp);
        txtViewLastMeasureDate = (TextView) view.findViewById(R.id.last_measure_date_txt_view_imp);
        txtViewLastMeasureHour = (TextView) view.findViewById(R.id.last_measure_hour_txt_view_imp);

        // Allow to make JSON Request (Essential !!!)
        requestQueue = Volley.newRequestQueue(getContext());

        getLastMeasure();
        getLastUserActivity();

        // Thread to update the last measurement and the last user state during this measurement every five second
        thread = new Thread(){
            @Override
            public void run() {
                while (!isInterrupted()){
                    try{
                        if(getActivity() != null){
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    getLastMeasure();
                                    getLastUserActivity();
                                }
                            });
                            Thread.sleep(5000);
                        }
                    } catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
            }
        };
        thread.start();

        return view;
    }

    // Get the last pulse measurement from ThingSpeak and set the textview to print this last measurement in it
    public void getLastMeasure(){

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, pulseUrlAddress, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i("Info", "Today Frag: Data received !");

                        try {
                            JSONArray feeds = response.getJSONArray("feeds");
                            JSONObject jo = feeds.getJSONObject(feeds.length()-1);

                            String field1_data = jo.getString("field1");
                            String date_data = jo.getString("created_at");

                            txtViewLastMeasure.setText(field1_data);
                            setDateHour(date_data);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.i("Info", "Fail to receive data !");
                    }
                });
        requestQueue.add(jsonObjectRequest);
    }

    // Get the last uesr activity measurement from ThingSpeak and set the textview to print this last measurement in it
    public void getLastUserActivity(){

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, accelerometerUrlAddress, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i("Info", "Today Frag: Data received !");

                        try {
                            JSONArray feeds = response.getJSONArray("feeds");
                            JSONObject jo = feeds.getJSONObject(feeds.length()-1);

                            String field2_data = jo.getString("field2");
                            if(field2_data != "null") {
                                if (field2_data.equals("1")) {
                                    txtViewLastUserActivity.setText("active.");
                                } else {
                                    txtViewLastUserActivity.setText("on rest.");
                                }
                            } else {
                                txtViewLastUserActivity.setText("on rest.");
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.i("Info", "Fail to receive data !");
                    }
                });
        requestQueue.add(jsonObjectRequest);
    }

    // Cut the string of the date and the hour of the measurement and set those values in the associed textviews
    public void setDateHour(String data){

        String separatedOne[] = data.split("T");
        txtViewLastMeasureDate.setText(separatedOne[0]);
        String separatedTwo[] = separatedOne[1].split("Z");
        txtViewLastMeasureHour.setText(separatedTwo[0]);
    }

}
