package com.linda.pulserateapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    // Variables initialisation
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button logInBtn;
    private TextView wrongLoginDetailsTextView;

    // Username and password by default
    final String GOOD_USERNAME = "Linda123";
    final String GOOD_PASSWORD = "123";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the layout that will be printed
        setContentView(R.layout.activity_login);

        // Set all the textViews
        usernameEditText = (EditText) findViewById(R.id.username_edit_text);
        passwordEditText = (EditText) findViewById(R.id.password_edit_text);
        logInBtn = (Button) findViewById(R.id.log_in_btn);
        wrongLoginDetailsTextView = (TextView) findViewById(R.id.wrong_login_details_txtview);

        // On the click of the "login" button, get the written values by the user for the username and the password
        // If both are good, we open the main activity otherwise it will display a textView to say that they are wrong
        logInBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                if (username.equals(GOOD_USERNAME) && password.equals(GOOD_PASSWORD)){
                    wrongLoginDetailsTextView.setText("");
                    openMainActivity();
                }
                else {
                    wrongLoginDetailsTextView.setText("Username or password wrong !");
                }
            }
        });
    }

    // Function to open the MainActivity
    public void openMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    // When this activity is stopping, erase the username and the password entered by the user
    @Override
    protected void onStop() {
        super.onStop();
        usernameEditText.setText("");
        passwordEditText.setText("");
    }
}
