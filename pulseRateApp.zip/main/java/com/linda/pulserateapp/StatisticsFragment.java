package com.linda.pulserateapp;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.macroyau.thingspeakandroid.ThingSpeakChannel;
import com.macroyau.thingspeakandroid.ThingSpeakLineChart;
import com.macroyau.thingspeakandroid.model.ChannelFeed;

import java.util.Calendar;

import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.Viewport;
import lecho.lib.hellocharts.view.LineChartView;

public class StatisticsFragment extends Fragment {

    // Variable initialisation
    private ThingSpeakChannel tsPrivateChannel;
    private ThingSpeakLineChart tsPrivateChart;
    private LineChartView chartView;
    private ProgressDialog progressDialog;
    // Our ThingSpeak Private channel
    final int CHANNEL_ID = 620080;
    // Channel Field that we want to display
    final int FIELD_ID = 1;
    // Our ThingSpeak Private channel Read API Key
    private String READ_API_KEY = "5JV8F8O1J1FSMW7G";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Display a loading progress dialog
        progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading ...");
        progressDialog.show();

        // Set the layout that will be printed
        View view = inflater.inflate(R.layout.fragment_statistics, container, false);

        // Connect to ThinkSpeak Channel n°CHANNEL_ID
        tsPrivateChannel = new ThingSpeakChannel(CHANNEL_ID, READ_API_KEY);
        // Set listener for Channel feed update events
        tsPrivateChannel.setChannelFeedUpdateListener(new ThingSpeakChannel.ChannelFeedUpdateListener() {
            @Override
            public void onChannelFeedUpdated(long channelId, String channelName, ChannelFeed channelFeed) {
                Log.i("Feeds number", String.valueOf(channelFeed.getFeeds().size()));
                progressDialog.dismiss();
            }
        });
        // Fetch the specific Channel feed
        tsPrivateChannel.loadChannelFeed();
        Log.i("Feeds ", "Feeds loaded !");

        // Create a Calendar object dated 5 minutes ago
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MINUTE, -5);

        // Configure LineChartView
        chartView = (LineChartView) view.findViewById(R.id.chart);
        chartView.setZoomEnabled(true);
        chartView.setValueSelectionEnabled(true);

        // Create a line chart from Field 1 of ThinkSpeak Channel 1
        tsPrivateChart = new ThingSpeakLineChart(CHANNEL_ID, FIELD_ID, READ_API_KEY);
        // Get 200 entries at maximum
        tsPrivateChart.setNumberOfEntries(50);
        // Set value axis labels on 10-unit interval
        tsPrivateChart.setValueAxisLabelInterval(10);
        // Set date axis labels on 5-minute interval
        tsPrivateChart.setDateAxisLabelInterval(5);
        // Show the line as a cubic spline
        tsPrivateChart.useSpline(true);
        // Set the line color
        tsPrivateChart.setLineColor(Color.parseColor("#D32F2F"));
        // Set the axis color
        tsPrivateChart.setAxisColor(Color.parseColor("#455a64"));
        // Set the starting date (5 minutes ago) for the default viewport of the chart
        tsPrivateChart.setChartStartDate(calendar.getTime());
        // Set listener for chart data update
        tsPrivateChart.setListener(new ThingSpeakLineChart.ChartDataUpdateListener() {
            @Override
            public void onChartDataUpdated(long channelId, int fieldId, String title, LineChartData lineChartData, Viewport maxViewport, Viewport initialViewport) {
                // Set chart data to the LineChartView
                chartView.setLineChartData(lineChartData);
                // Set scrolling bounds of the chart
                chartView.setMaximumViewport(maxViewport);
                // Set the initial chart bounds
                chartView.setCurrentViewport(initialViewport);
            }
        });
        // Load chart data asynchronously
        tsPrivateChart.loadChartData();
        Log.i("Chart ", "Chart loaded !");

        return view;
    }

}
